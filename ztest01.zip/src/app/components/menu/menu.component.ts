import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit{
  
  isCollapsed = false;

  public menulist:any=[
    {
      group:'1',
      menuname:'父菜单1',
      menuchil:[
        {
          menuchilname:'子菜单1',
        },
        {
          menuchilname:'子菜单2',
        }
      ]
    }
  ]

  constructor(){}

  ngOnInit(): void {
    
  }
}
