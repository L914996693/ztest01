import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuard } from '../../auth/auth.guard';

import { MenuComponent } from './menu.component';

const routes: Routes = [
  { 
    path:'',data: {
      breadcrumb: 'Display Name'
    },component:MenuComponent,
    /* children:[
      {path:'register',canActivateChild: [AuthGuard],component:RegisterComponent},
    ] */
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MenuRoutingModule { }
