import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuard } from './auth/auth.guard';


const routes: Routes = [
  { path:'',pathMatch:'full',redirectTo:'login'},
  { path: 'login', loadChildren: () => import('./components/login/login.module').then(m => m.LoginModule) },
  { path: 'menu',canActivate:[AuthGuard] ,data:{breadcrumb: 'First'}, loadChildren: () => import('./components/menu/menu.module').then(m => m.MenuModule) }//canActivate:[AuthGuard] ,
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
